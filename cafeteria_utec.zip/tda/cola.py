# -*- coding: utf-8 -*-
"""
TDA: Cola (FIFO - Primeras Entradas, Primeras Salidas)
--------------------------------------------------------
Se usa UNA instancia por fila (pedidos normales y pedidos prioritarios).
La cola solo garantiza que, DENTRO de ella, el primero en entrar es el
primero en salir. La regla de "la fila prioritaria se prepara primero"
vive en controllers/estado.py, no aqui.
"""


class Cola:
    def __init__(self):
        self._datos = []

    def __len__(self):
        return len(self._datos)

    def encolar(self, elemento):
        """Agrega un elemento al FINAL de la fila."""
        self._datos.append(elemento)

    def desencolar(self):
        """Quita y regresa el elemento del FRENTE. Si esta vacia, regresa None."""
        if self.esta_vacia():
            return None
        return self._datos.pop(0)

    def frente(self):
        """Consulta quien es el siguiente, SIN quitarlo de la fila."""
        if self.esta_vacia():
            return None
        return self._datos[0]

    def esta_vacia(self):
        return len(self._datos) == 0

    def tamano(self):
        return len(self._datos)

    def obtener_todos(self):
        """Regresa la fila completa, en orden de llegada."""
        return list(self._datos)

    def eliminar(self, predicado):
        """
        Quita y regresa el primer elemento que cumple predicado(elemento),
        sin importar en que posicion este (se usa para cancelar un pedido
        que esta en medio de la fila). Los demas conservan su orden.
        Si ninguno cumple, regresa None.
        """
        for i, elemento in enumerate(self._datos):
            if predicado(elemento):
                return self._datos.pop(i)
        return None
