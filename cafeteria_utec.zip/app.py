import web

# Evita que el servidor de desarrollo espere una resolucion DNS inversa
# por cada peticion (hacia lento cada click dentro de Codespaces).
import http.server
http.server.BaseHTTPRequestHandler.address_string = lambda self: self.client_address[0]

urls = (
    '/', 'controllers.index.Index',
    '/registrar_pedido', 'controllers.registrar_pedido.RegistrarPedido',
    '/preparar_pedido', 'controllers.preparar_pedido.PrepararPedido',
    '/siguiente_pedido', 'controllers.siguiente_pedido.SiguientePedido',
    '/pedidos', 'controllers.pedidos.Pedidos',
    '/estadisticas', 'controllers.estadisticas.Estadisticas',
    '/cancelar_pedido', 'controllers.cancelar_pedido.CancelarPedido',
)
app = web.application(urls, globals())

if __name__ == "__main__":
    app.run()
