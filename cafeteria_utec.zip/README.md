# Cafeteria UTEC - Sistema de pedidos (dos filas FIFO)

La cafeteria maneja DOS filas: pedidos normales y pedidos prioritarios
(clientes con clases proximas). Dentro de cada fila se respeta FIFO; al
preparar un pedido se atiende primero la fila prioritaria y, si esta
vacia, la normal.

Misma estructura que los ejercicios anteriores (web.py + controllers +
views + tda). El TDA `Cola` es el mismo, con un metodo extra
(`eliminar`) para poder cancelar un pedido que esta en medio de la fila.

## Estructura

```
cafeteria_utec/
├── app.py
├── controllers/
│   ├── estado.py             # las 2 colas, contadores y la regla de prioridad
│   ├── index.py              # menu
│   ├── registrar_pedido.py
│   ├── preparar_pedido.py
│   ├── siguiente_pedido.py
│   ├── pedidos.py            # pendientes
│   ├── estadisticas.py
│   └── cancelar_pedido.py
├── tda/cola.py               # el TDA: Cola (FIFO)
├── temporal/app.py
└── views/                    # una vista por pantalla
```

## Requerimientos -> donde estan

| Requerimiento | Ruta | TDA |
|---|---|---|
| 1. Registrar pedido | `/registrar_pedido` | `Cola.encolar()` en la fila que corresponda |
| 2. Preparar el siguiente pedido | `/preparar_pedido` | `cola_a_preparar()` + `Cola.desencolar()` |
| 3. Consultar el siguiente pedido | `/siguiente_pedido` | `cola_a_preparar()` + `Cola.frente()` |
| 4. Mostrar pedidos pendientes | `/pedidos` | `Cola.obtener_todos()` de cada fila |
| 5. Consultar estadisticas | `/estadisticas` | `Cola.tamano()`, `Cola.obtener_todos()` y contadores |
| 6. Cancelar pedido | `/cancelar_pedido` | `Cola.eliminar()` |

## Datos de cada pedido

Numero de pedido (automatico), nombre del cliente, producto, cantidad,
tipo de producto (Normal o Prioritario) y tiempo de preparacion (min).

## Regla de prioridad (controllers/estado.py)

```python
def cola_a_preparar():
    if not cola_prioritaria.esta_vacia():
        return cola_prioritaria
    return cola_normal
```

## Cancelar un pedido

Se busca por numero de pedido en las dos filas. El pedido se quita de
su lugar y los demas conservan su orden de llegada.

## Estadisticas

Pendientes (total, por fila), unidades pendientes, tiempo total y
promedio de preparacion pendiente, pedidos preparados y cancelados.

## Como correrlo

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 app.py
```

Los pedidos viven en memoria mientras el servidor esta corriendo.
