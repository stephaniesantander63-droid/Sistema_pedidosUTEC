import web

from controllers.estado import cola_a_preparar, nombre_de_fila

render = web.template.render('views', base='layout')


class SiguientePedido:
    def GET(self):
        cola = cola_a_preparar()
        siguiente = cola.frente()
        fila = nombre_de_fila(cola) if siguiente else None
        return render.siguiente_pedido(siguiente, fila)
