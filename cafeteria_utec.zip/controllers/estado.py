# -*- coding: utf-8 -*-
"""
Estado compartido del sistema, mientras el servidor esta corriendo:
- las dos colas (normal y prioritaria)
- contadores: siguiente numero de pedido, preparados y cancelados
"""
from tda.cola import Cola

cola_normal = Cola()
cola_prioritaria = Cola()

contadores = {'siguiente': 1, 'preparados': 0, 'cancelados': 0}


def generar_numero_pedido():
    """Asigna un numero de pedido unico y consecutivo."""
    numero = contadores['siguiente']
    contadores['siguiente'] += 1
    return numero


def cola_a_preparar():
    """
    Regresa la cola de la que debe salir el SIGUIENTE pedido: si la fila
    prioritaria tiene pedidos, se prepara de ahi; si esta vacia, de la
    normal. Dentro de cada fila el orden es FIFO.
    """
    if not cola_prioritaria.esta_vacia():
        return cola_prioritaria
    return cola_normal


def nombre_de_fila(cola):
    return 'Prioritario' if cola is cola_prioritaria else 'Normal'
