import web

from controllers.estado import cola_normal, cola_prioritaria, generar_numero_pedido

render = web.template.render('views', base='layout')


class RegistrarPedido:
    def GET(self):
        return render.registrar_pedido(None)

    def POST(self):
        entrada = web.input(
            nombre_cliente='', producto='', cantidad='',
            tipo_producto='Normal', tiempo_preparacion=''
        )

        nombre_cliente = entrada.nombre_cliente.strip()
        producto = entrada.producto.strip()
        tipo_producto = entrada.tipo_producto.strip()

        if not nombre_cliente or not producto:
            return render.registrar_pedido("El nombre del cliente y el producto son obligatorios.")

        try:
            cantidad = int(entrada.cantidad.strip())
            tiempo_preparacion = int(entrada.tiempo_preparacion.strip())
        except ValueError:
            return render.registrar_pedido(
                "La cantidad y el tiempo de preparacion deben ser numeros enteros."
            )

        if cantidad < 1 or tiempo_preparacion < 1:
            return render.registrar_pedido(
                "La cantidad y el tiempo de preparacion deben ser mayores a 0."
            )

        if tipo_producto not in ('Normal', 'Prioritario'):
            tipo_producto = 'Normal'

        pedido = {
            'numero_pedido': generar_numero_pedido(),
            'nombre_cliente': nombre_cliente,
            'producto': producto,
            'cantidad': cantidad,
            'tipo_producto': tipo_producto,
            'tiempo_preparacion': tiempo_preparacion,
        }

        if tipo_producto == 'Prioritario':
            cola_prioritaria.encolar(pedido)
        else:
            cola_normal.encolar(pedido)

        # Redirect RELATIVO a mano (en Codespaces web.seeother te saca a localhost)
        web.ctx.status = '303 See Other'
        web.header('Location', '/pedidos')
        return ''
