import web

from controllers.estado import cola_normal, cola_prioritaria

render = web.template.render('views', base='layout')


class Pedidos:
    def GET(self):
        return render.pedidos(cola_normal.obtener_todos(), cola_prioritaria.obtener_todos())
