import web

from controllers.estado import cola_normal, cola_prioritaria, contadores

render = web.template.render('views', base='layout')


class Estadisticas:
    def GET(self):
        pendientes = cola_normal.obtener_todos() + cola_prioritaria.obtener_todos()
        total = len(pendientes)
        tiempo_total = sum(p['tiempo_preparacion'] for p in pendientes)

        estadisticas = {
            'total_pendientes': total,
            'normales': cola_normal.tamano(),
            'prioritarios': cola_prioritaria.tamano(),
            'unidades': sum(p['cantidad'] for p in pendientes),
            'tiempo_total': tiempo_total,
            'tiempo_promedio': round(tiempo_total / total, 1) if total else 0,
            'preparados': contadores['preparados'],
            'cancelados': contadores['cancelados'],
        }
        return render.estadisticas(estadisticas)
