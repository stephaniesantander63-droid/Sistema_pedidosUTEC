import web

from controllers.estado import cola_normal, cola_prioritaria, contadores

render = web.template.render('views', base='layout')


class CancelarPedido:
    def GET(self):
        return self.mostrar(None, None)

    def POST(self):
        entrada = web.input(numero_pedido='')

        try:
            numero = int(entrada.numero_pedido.strip())
        except ValueError:
            return self.mostrar("Escribe el numero de pedido (solo numeros).", 'error')

        # Se busca en las dos filas; el pedido sale de su lugar y los demas
        # conservan su orden.
        cancelado = cola_prioritaria.eliminar(lambda p: p['numero_pedido'] == numero)
        if cancelado is None:
            cancelado = cola_normal.eliminar(lambda p: p['numero_pedido'] == numero)

        if cancelado is None:
            return self.mostrar("No existe el pedido #%d entre los pendientes." % numero, 'error')

        contadores['cancelados'] += 1
        return self.mostrar(
            "Se cancelo el pedido #%d de %s (%s)." % (
                cancelado['numero_pedido'], cancelado['nombre_cliente'], cancelado['producto']
            ),
            'ok',
        )

    def mostrar(self, mensaje, tipo):
        return render.cancelar_pedido(
            cola_normal.obtener_todos(), cola_prioritaria.obtener_todos(), mensaje, tipo
        )
