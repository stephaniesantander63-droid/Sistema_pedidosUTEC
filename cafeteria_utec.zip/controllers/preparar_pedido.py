import web

from controllers.estado import cola_a_preparar, contadores

render = web.template.render('views', base='layout')


class PrepararPedido:
    def GET(self):
        cola = cola_a_preparar()
        preparado = cola.desencolar()

        if preparado:
            contadores['preparados'] += 1

        return render.preparar_pedido(preparado)
